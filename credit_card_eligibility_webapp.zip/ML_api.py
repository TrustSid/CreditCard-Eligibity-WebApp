import joblib
import pandas as pd
from flask import Flask, request, jsonify, render_template

# Load the trained model
model = joblib.load('model.pkl')

# Initialize the Flask application
app = Flask(__name__)

# Define the root route that renders the form
@app.route('/')
def form():
    return render_template('form.html')

# Define the route that handles the form submission
@app.route('/loan', methods=['POST'])
def loan():
    # Get the input data from the form
    Age = int(request.form['Age'])
    Married = int(request.form['Married'])
    BankCustomer = int(request.form['BankCustomer'])
    PriorDefault = int(request.form['PriorDefault'])
    Employed = int(request.form['Employed'])
    CreditScore = int(request.form['CreditScore'])
    has_income = 'has_income' in request.form
    Income = int(request.form['Income']) if has_income else 0
    Citizen_Status = request.form['Citizen_Status']

    # Initialize the credit score categories
    VeryPoorCredit = 0
    PoorCredit = 0
    FairCredit = 0
    GoodCredit = 0

    # Determine the correct category based on the CreditScore
    if 0 <= CreditScore <= 16:
        VeryPoorCredit = 1
    elif 17 <= CreditScore <= 33:
        PoorCredit = 1
    elif 34 <= CreditScore <= 50:
        FairCredit = 1
    elif 51 <= CreditScore <= 67:
        GoodCredit = 1

    # Initialize the citizen status categories
    Citizen_ByBirth = 0
    Citizen_ByOtherMeans = 0
    Citizen_Temporary = 0

    # Determine the correct category based on the Citizen_Status
    if Citizen_Status == 'ByBirth':
        Citizen_ByBirth = 1
    elif Citizen_Status == 'ByOtherMeans':
        Citizen_ByOtherMeans = 1
    elif Citizen_Status == 'Temporary':
        Citizen_Temporary = 1

    # Convert the input data into a dict
    input_dict = {
    'Age': [Age],
    'Married': [Married],
    'BankCustomer': [BankCustomer],
    'PriorDefault': [PriorDefault],
    'Employed': [Employed],
    'CreditScore': [CreditScore],
    'Income': [Income],
    'Citizen_ByBirth': [Citizen_ByBirth],
    'Citizen_ByOtherMeans': [Citizen_ByOtherMeans],
    'Citizen_Temporary': [Citizen_Temporary],
    'FairCredit': [FairCredit],
    'GoodCredit': [GoodCredit],
    'PoorCredit': [PoorCredit],
    'VeryPoorCredit': [VeryPoorCredit],
    'has_income': [1 if has_income else 0]
    }

    # Convert the input data into a DataFrame
    input_df = pd.DataFrame.from_dict(input_dict)

    # Use the model to predict the loan approval
    prediction = model.predict(input_df)[0]

    # Define the message based on the prediction
    message = "CONGRATULATIONS! YOU'RE ELIGIBLE FOR OUR CREDIT CARD" if prediction == 1 else "SORRY BUT YOU DO NOT MEET THE NECESSARY CONDITIONS TO AVAIL CREDIT CARD"
    color = "green" if prediction == 1 else "red"

    # Render the result page with the message
    return render_template('result.html', message=message, color=color)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

